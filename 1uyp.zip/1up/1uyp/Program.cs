﻿using System;

namespace _1uyp
{
    // @name: Program.cs
    // @author: bartramj025070

    // Skole
    public class Player
    {
        // Maksimale variabler
        public int MaxHealth = 100;
        public int MaxMana = 50;
        public int MaxPowerLvl = 50;

        // Datavariabler
        public int Health = 100;
        public int Mana = 50;
        public int PowerLevel = 0;

        public Move[] AllMoves = new Move[] {
            new Move("Fireball", 15, 10, "fire"),
            new Move("Fireblast", 20, 30, "fire"),
            new Move("Waterball", 15, 10, "water"),
            new Move("Whirlpool", 20, 30, "water"),
            new Move("Kick", 20, 30, "fast"),
            new Move("None", 0, -100, "none")
        };

        // Konstruktør
        public Player()
        {
            this.MaxHealth = MaxHealth;
            this.MaxMana = MaxMana;
            this.MaxPowerLvl = MaxPowerLvl;

            this.Health = Health;
            this.Mana = Mana;
            this.PowerLevel = PowerLevel;

            this.AllMoves = AllMoves;
        }
    }

    public class Enemy
    {
        public String Name;
        public int[] DamageDrainRange;
        public int[] ManaDrainRange;
        public Move[] AllMoves;

        public int MaxHealth;
        public int MaxMana;

        public double Health;
        public double Mana;

        public String Type;

        public void Reset()
        {
            this.Health = this.MaxHealth;
            this.Mana = this.MaxMana;
        }

        public Enemy(String Name, int MaxHealth, int MaxMana, String Type, int[] DamageDrainRange, int[] ManaDrainRange, Move[] AllMoves)
        {
            this.Name = Name;
            this.MaxHealth = MaxHealth;
            this.MaxMana = MaxMana;

            this.Health = MaxHealth;
            this.Mana = MaxMana;

            this.Type = Type;

            this.DamageDrainRange = DamageDrainRange;
            this.AllMoves = AllMoves;
        }
    }

    public class Move
    {
        // Konstruktør

        public String Name;
        public int Damage;
        public String Type;
        public int ManaRequired;
        public String[] Requirements;
        public Move(String _name, int _damage, int _ManaRequired, String _type, String[] _requirements=null) {
            this.Name = _name;
            this.Damage=_damage;
            this.Type=_type;
            this.ManaRequired=_ManaRequired;
            this.Requirements=(_requirements == null) ? new String[] { } : _requirements; /* IF REQUIREMENTS ISN'T SET, CREATE AN EMPTY STRING ARRAY */
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Random RandomRange = new Random();

            Player Spiller = new Player();
            Enemy[] AllEnemies = new Enemy[]
            {
                new Enemy("Fish", 100, 50, "water", new int[] { 1, 5 }, new int[] { 10, 25 }, new Move[] {
                    new Move("Waterball", 10, 20, "water"),

                    new Move("None", 0, -100, "none")
                }),

                new Enemy("Vending Machine", 100, 50, "fire", new int[] { 1, 5 }, new int[] { 10, 25 }, new Move[] {
                    new Move("Packet of Crisps", 5, 0, "projectile"),
                    new Move("Bo'oll o' wa'er", 20, 10, "water"),
                    new Move("None", 0, -100, "none")
                }),

                new Enemy("Programmer", 5000, 250, "smart", new int[] { 1, 5 }, new int[] { 10, 25 }, new Move[] {
                    new Move("player.Damage(15);", 15, 10, "exact"),
                    new Move("player.Damage(25);", 25, 20, "exact"),
                    new Move("game.End(this.access<Code>(\"GAME_END_CODE\"));", 75, 250, "exact"),
                    new Move("enemy.Mana = Math.Min(enemy.Mana + 1000, enemy.MaxMana);", 0, -100, "none")
                }),
            };

            Enemy CurrentEnemy;

            String CheckInput(String InputText="")
            {
                if (InputText != "") { Console.WriteLine(InputText); }
                return Console.ReadLine();
            }

            Move GetMove(String input, Move[] moves) {
                for (int i = 0; i < moves.Length; i++)
                {
                    Move move = moves[i];
                    if (move != null)
                    {
                        if (move.Name.ToLower() == input.ToLower()) {
                            return move;
                        }
                    }
                }

                return null;
            }

            void BeginFight()
            {
                int index = RandomRange.Next(AllEnemies.Length);
                
                CurrentEnemy = AllEnemies[index];
                CurrentEnemy.Reset();

                Console.WriteLine("You encountered a " + CurrentEnemy.Name.ToLower() + "!");

                ConstructPlayset();
            }

            Move retrieveNonRest()
            {
                int Length = CurrentEnemy.AllMoves.Length;
                Move[] moveList = new Move[Length];

                for (int i = 0; i < Length; i++)
                {
                    Move move = CurrentEnemy.AllMoves[i];
                    if (move.ManaRequired <= CurrentEnemy.Mana)
                    {
                        moveList[i] = move;
                    }
                }

                Move selectedMove = moveList[new Random().Next(Length)];
                if (selectedMove == null)
                {
                    return retrieveNonRest();
                }
                if (selectedMove.Name == "None" && moveList.Length > 1) {
                    return retrieveNonRest();
                } else {
                    return selectedMove;
                }
            }

            void ConstructEnemyMove() {
                Move selectedMove = retrieveNonRest();
                int Damage = CurrentEnemy.Type == "exact" ? selectedMove.Damage : Math.Max((selectedMove != null) ? selectedMove.Damage + RandomRange.Next(-(selectedMove.Damage / 2), selectedMove.Damage / 2) : selectedMove.Damage / 2, 0);
                int didMiss = new Random().Next(0, 4);

                if (selectedMove.Name == "None")
                {
                    Console.WriteLine("THE ENEMY " + CurrentEnemy.Name.ToUpper() + " TOOK A REST.");
                    CurrentEnemy.Mana = Math.Min(CurrentEnemy.MaxMana, CurrentEnemy.Mana + 100);
                }
                else {
                    int didRest = new Random().Next(0, 6);
                    if (didRest == 0 || CurrentEnemy.Mana == 0)
                    {
                        Console.WriteLine("THE ENEMY " + CurrentEnemy.Name.ToUpper() + " TOOK A REST.");
                        CurrentEnemy.Mana = Math.Min(CurrentEnemy.MaxMana, CurrentEnemy.Mana + 100);
                        return;
                    }
                    CurrentEnemy.Mana = Math.Max(0, selectedMove.ManaRequired);
                    if (didMiss == 0)
                    {
                        Console.WriteLine("THE ENEMY " + CurrentEnemy.Name.ToUpper() + " TRIED TO USE " + selectedMove.Name.ToUpper() + " BUT MISSED AND DEALT 0 DMG!");
                    }
                    else
                    {
                        if (Damage == 0)
                        {
                            Console.WriteLine("THE ENEMY " + CurrentEnemy.Name.ToUpper() + " TRIED TO USE " + selectedMove.Name.ToUpper() + " BUT MISSED AND DEALT 0 DMG!");
                        }
                        else
                        {
                            Console.WriteLine("THE " + CurrentEnemy.Name.ToUpper() + " USED " + selectedMove.Name.ToUpper() + "! IT DEALT " + Damage.ToString().ToUpper() + " DMG!");
                            Spiller.Health = Math.Max(Spiller.Health - Damage, 0);

                            if (Spiller.Health == 0)
                                {
                                    Console.WriteLine("THE ENEMY " + CurrentEnemy.Name.ToUpper() + " HAS KILLED YOU, TRY AGAIN!");
                                }
                        }
                    }
                }
            }

            void ConstructFight() {
                Console.Clear();

                int Length = Spiller.AllMoves.Length;
                Move[] moveList = new Move[400];
                for (int i = 0; i < Length; i++)
                {
                    Move move = Spiller.AllMoves[i];
                    if (move.ManaRequired <= Spiller.Mana)
                    {
                        moveList[i] = move;
                    }
                }

                for (int i = 0; i < Length; i++)
                {
                    Move move = moveList[i];
                    if (move != null)
                    {
                        Console.WriteLine(move.Name.ToUpper() + ": " + ((move.ManaRequired > 0) ? (-move.ManaRequired).ToString() : "+" + (-move.ManaRequired).ToString()) + " MANA | " + move.Damage.ToString() + " DAMAGE");
                    }
                }

                String response = CheckInput("\nYOU HAVE: \n   " + Spiller.Mana.ToString() + "/" + Spiller.MaxMana.ToString() + " MANA\n   " + Spiller.Health + "/" + Spiller.MaxHealth + " HEALTH" + "\n\nENEMY " + CurrentEnemy.Name.ToUpper() + " HAS:\n   " + CurrentEnemy.Mana.ToString() + "/" + CurrentEnemy.MaxMana.ToString() + " MANA\n   " + CurrentEnemy.Health.ToString() + "/" + CurrentEnemy.MaxHealth.ToString() + " HEALTH\n\nSelect your move: ");
                Move SelectedMove = GetMove(response, moveList);

                if (SelectedMove != null)
                {
                    if (SelectedMove.Name == "None") { Console.WriteLine("You took a pause and rested, +100 MANA"); Spiller.Mana = Math.Min(Spiller.MaxMana, Spiller.Mana + 100); ConstructEnemyMove(); ConstructPlayset(); return; }

                    Spiller.Mana = Math.Max(0, Spiller.Mana - SelectedMove.ManaRequired);

                    int Missed = new Random().Next(0, 4);
                    if (Missed == 1)
                    {
                        Console.WriteLine("Your move missed and dealt 0 DMG!");
                    }
                    else {
                        double Multiplier = 1;
                        switch (SelectedMove.Type) {
                            case "fire":
                                if (CurrentEnemy.Type == "water")
                                {
                                    Multiplier -= 0.25;
                                }
                                break;

                            case "water":
                                if (CurrentEnemy.Type == "fire") {
                                    Multiplier += 0.25;
                                }
                                break;
                            case "projectile":
                                if (CurrentEnemy.Type == "fast") {
                                    Multiplier -= 0.25;
                                }
                                break;
                            case "fast":
                                if (CurrentEnemy.Type == "projectile")
                                {
                                    Multiplier += 0.25;
                                }
                                break;
                            default:
                                if (SelectedMove.Type != "none")
                                {
                                    if (CurrentEnemy.Type == "none")
                                    {
                                        Multiplier += 0.25;
                                    }
                                }
                                break;
                        }

                        double Damage = RandomRange.Next(SelectedMove.Damage - 5, SelectedMove.Damage + 5) * Multiplier;
                        Console.WriteLine("Your move hit and dealt " + Damage.ToString() + " DMG!");

                        CurrentEnemy.Health = Math.Max(0, CurrentEnemy.Health - Damage);

                        if (Multiplier < 1 && Multiplier > 0.5)
                        {
                            Console.WriteLine("Your attack was inaffective and dealt less damage!");
                        }

                        if (Multiplier < 1 && Multiplier < 0.5)
                        {
                            Console.WriteLine("Your attack was super inaffective and dealt less damage!");
                        }

                        if (Multiplier > 1 && Multiplier < 1.5)
                        {
                            Console.WriteLine("Your attack was affective and dealt more damage!");
                        }

                        if (Multiplier > 1 && Multiplier >= 1.5)
                        {
                            Console.WriteLine("Your attack was super affective and dealt more damage!");
                        }

                        // Console.WriteLine("Multiplier: " + Multiplier.ToString());
                    }

                    ConstructEnemyMove();
                    ConstructPlayset();
                }
                else
                {
                    ConstructFight();
                }
            }

            void ConstructPlayset(String forcedResponse=null) {
                String response = (forcedResponse != null) ? forcedResponse : (CheckInput("Categories:\nFIGHT ACT"));

                if (response.ToUpper() == "FIGHT")
                {
                    ConstructFight();
                }
                else if (response.ToUpper() == "ACT")
                {
                    Console.Clear();

                    response = CheckInput();
                }
                else {
                    Console.Clear();
                    ConstructPlayset();
                }
            }

            BeginFight();
        }
    }
}
